Documents: 
Read the "views/page/docs.html" or "html/docs.html"
